<template>
  <q-page-container>
    <q-page class="flex flex-center">
      {{ message }}
    </q-page>
    
  </q-page-container>
</template>

<style>
</style>

<script>
export default {
  name: 'HelloWorld',
  data: {
    message: "Connectez-vous"
  }
}
</script>
