<template>
    <div class="q-pa-md" >
        <q-form class="q-gutter-md fixed-center">
            <q-input filled bg-color="blue-grey-3" label="Votre e-mail"/>
            <q-input filled bg-color="blue-grey-3" label="Votre password"/>
        </q-form>
    </div>
</template>