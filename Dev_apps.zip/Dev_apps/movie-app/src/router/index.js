import Vue from 'vue'
import VueRouter from 'vue-router'
Vue.use(VueRouter)

import LatestMovie from '@/components/LatestMovie'
import Movie from '@/components/Movie'

export default new VueRouter({
  //mode: history,
  routes: [
    {
      path: '/',
      name: 'LatestMovie',
      component: LatestMovie
    },
    {
      path: '/movie/:id',
      name: 'Movie',
      props: true,
      component: Movie
    },
  ]
})