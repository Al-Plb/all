<template>
    <q-layout>
      <q-page-container>
        <q-page>
          <router-view/>
          <footerPolldle/>
        </q-page>
      </q-page-container>
    </q-layout>
</template>

<script>
// import HelloWorld from './components/HelloWorld.vue';
import footerPolldle from "@/components/FooterPolldle.vue";


export default {
  name: 'LayoutDefault',

  components: {
    footerPolldle
  },
}
</script>

<style>
</style>
