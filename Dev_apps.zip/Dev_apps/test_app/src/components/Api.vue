<template>
<h1>{{ text }}</h1>
</template>

<script>
export default {
  name: "Api",
  data() {
    return {
     text: "Salut"
    };
  }
}

</script>