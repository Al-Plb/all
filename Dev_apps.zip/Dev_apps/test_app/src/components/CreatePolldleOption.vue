<template >
  <div class="polldle-option-input row justify-content-center ">
    <div class="col col-auto">
      <q-input
        outlined
        type="text"
        readonly
        v-bind:value="polldleOption.text"
        v-bind:title="polldleOption.text"
        
      />
    </div>
    <div class="col col-auto">
      <!-- Directive v-on with removePolldleOption -->
      <q-btn
        type="button"
        @click="removePolldleOption(polldleOption)"
        
      >X</q-btn>
    </div>
  </div>
</template>

<script>
export default {
  name: "CreatePolldleOption",
  data() {
    return {
        errorMessage: "",
        polldleOption:"",
    };
  },

  methods: {
    removePolldleOption(polldleOption) {
      this.$emit("removed-polldle-option", polldleOption);
    }
  },
  // Add properties definition on polldleOption object
  props: {
    polldleOption: {
      type: Object,
      required: true
    }
  }
};
</script>

<style>
.polldle-option-input {
  margin-bottom: 5px;
}
</style>