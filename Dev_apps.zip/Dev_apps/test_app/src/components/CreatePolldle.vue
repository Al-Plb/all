<template>
  <div class="column items-center">
    <q-btn>
    </q-btn>
    <!-- Titre + description -->
    <h1>PollDLE</h1>
    <h3>Voting done simply in real-time</h3>

    <!-- PollDLE name -->
    <div class="row">
      <div class="col">
        <!-- Directive v-model with question -->
        <q-input outlined type="text" placeholder="Add your question here" v-model="question" />
      </div>
    </div>

    <h3>Add your PollDLE options</h3>

    <div class="row">
      <div class="col">
        <!-- Directive v-model with newPolldleOptionText -->
        <!-- Directive v-on with addPolldleOption -->
        <q-input
          outlined
          type="text"
          placeholder="Polldle Option"
          v-model="newPolldleOptionText"
          v-on:keypress.enter="addPolldleOption"
        />
      </div>
    </div>
    <!-- Directive v-show with buttonShown -->
    <div class="row" v-show="buttonShown">
      <div class="col">
        <!-- Directive v-on with clearAllPolldleOptions -->
        <q-btn
          color="negative"
          type="button"
          class="clear-button"
          @click="clearAllPolldleOptions"
        >Clear all PollDLE Options</q-btn>
      </div>
    </div>

    <!-- PollDLE option -->
      <!-- Directive v-for with polldleOptions -->
    <div 
      class="row justify-center"
      v-for="currentPolldleOption in polldleOptions"
      :key="currentPolldleOption.text"

    >
      <CreatePolldleOption :polldleOption="currentPolldleOption" @removed-polldle-option="removedPolldleOption($event)"/>
      <!-- {{ currentPolldleOption.text }} -->
    </div>

    <!-- Button Action -->
    <div class="row">
      <div class="col">
        <!-- Directive v-on with createPolldle -->
        <q-btn
          color="primary"
          type="button"
          class="validate-button"
          v-on:click="createPolldle"
          v-bind:disabled="isCreatePolldleDisabled()"
        >Create PollDLE</q-btn>
        <!-- v-if="!isCreatePolldleDisabled()"
        @click="confirm = true"-->
      </div>
    </div>
    <!-- <q-dialog v-model="confirm" persistent>
        <q-card>
          <q-card-section class="row items-center">
            <q-avatar icon="signal_wifi_off" color="primary" text-color="white" />
            <span class="q-ml-sm">Are you sure to create this polldle ?</span>
          </q-card-section>

          <q-card-actions align="right">
            <q-btn flat label="Cancel" color="primary" v-close-popup />
            <q-btn flat label="Ok" color="primary" v-close-popup @click="confirmCreatePolldle()"/>
          </q-card-actions>
        </q-card>
    </q-dialog>-->

    <div class="alert alert-primary" role="alert">
      <h4 class="alert-heading">Summary of your PollDLE</h4>
      <hr />
      <p>
        The question is:
        <strong>{{ question }}</strong>
      </p>
      <!-- Mustache with computed property: listSize  this.polldleOptions.length-->
      <p>Number of PollDLE options: {{ listSize }}</p>
    </div>
    <!-- Directive v-show with errorMessage -->
      <!-- Directive v-text with errorMessage -->
    <div
      v-show="errorMessage !== ''"
      class="error-message alert alert-danger"
      role="alert"
      v-text="errorMessage"
    ></div>
  </div>
</template>

<script>

// Import CreatePolldleOption component
import CreatePolldleOption from "@/components/CreatePolldleOption.vue";
export default {
  name: "CreatePolldle",
  // Add dependencies on CreatePolldleOption component
  components: { 
    CreatePolldleOption 
  },
  data() {
    return {
      text: "",
      question: "",
      newPolldleOptionText: "",
      polldleOptions: [],
      errorMessage: "Problem to create a new Polldle",
      buttonShown: false,
      confirm: false
    };
  },
  // Watcher on polldleOptions
  watch: {
    polldleOptions() {
      this.buttonShown =
        this.polldleOptions != null && !(this.polldleOptions.length === 0);
      // console.log(this.buttonShown);
    }
  },
  // Computed property listSize when polldleOptions changes
  computed: {
    listSize() {
      return this.polldleOptions.length;
    }
  },
   mounted() {
    console.log(this.$el.textContent);
  },
  methods: {
    removedPolldleOption(polldleOption) {
      let index = this.polldleOptions.indexOf(polldleOption);
      this.polldleOptions.splice(index, 1);
      this.errorMessage = "";
    },

    addPolldleOption() {
      this.polldleOptions.push({
        text: this.newPolldleOptionText
      });
      this.newPolldleOptionText = "";
    },

    clearAllPolldleOptions() {
      this.polldleOptions = [];
      this.errorMessage = "";
    },

    createPolldle() {
      var polldleObject = {
        question: this.question,
        polldleOptions: []
      };

      this.polldleOptions.forEach(element => {
        var newPollOptionElement = { name: element.text };
        if (element.text !== "") {
          polldleObject.polldleOptions.push(newPollOptionElement);
        }
      });

    //   // Call REST web service with fetch API
    //   var request = new Request("http://127.0.0.1:9991" + "/polldles", {
    //     method: "POST",
    //     body: JSON.stringify(polldleObject),
    //     headers: {
    //       'Content-Type': 'application/json'
    //     }
    //   })

    //   // Call REST web service with fetch API
    //   fetch(request).then(response => {
    //     if (response.ok) {
    //       return response.json();
    //     } else {
    //       this.errorMessage = "Problem to create a new Polldle.";
    //     }
    //   }).then(data => {
    //     console.log(data.pathUrl);
    //   }).catch((error) => {
    //     this.errorMessage = "Problem to create a new Polldle.";
    //     console.error(error);
    //   });
    },

    isCreatePolldleDisabled() {
      return (
        this.polldleOptions === null ||
        this.polldleOptions.length < 2 ||
        this.question === ""
      );
    }
    // confirmCreatePolldle() {
    //   alert("le polldle est crée")
    // }
  }
};
</script>

<style lang="stylus"></style>