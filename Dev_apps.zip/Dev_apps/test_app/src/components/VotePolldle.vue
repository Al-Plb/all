<template>
  <div>{{$route.params.pathurl }}</div>
</template>

<script>
export default {
  name: "VotePolldle",
  data() {
    return {
     
    };
  }
  ,
  created() {
    // // To retrieve PollDLE information from REST web service
    // axios.get("http://127.0.0.1:9991" + "/polldles", {
    //   params : {
    //     pathURL: this.$route.params.pathurl
    //   }
    // }).then(response => {
    //   if (response.status === 200) {
    //     this.question = response.data.question;
    //     this.polldleOptions = response.data.polldleOptions;
    //     this.state = stateResult.WAITING_VOTE;
    //   } else {
    //     this.errorMessage = "Polldle can not be loaded.";
    //     this.state = stateResult.ERROR;
    //   }  
    // }).catch(error => {
    //   this.errorMessage = "Polldle can not be loaded.";
    //   this.state = stateResult.ERROR;
    //   console.error(error);
    // });
  },
  // methods: {
  //   vote() {
  //     // Prepare the data
  //     var polldleVote = {
  //       pathUrl: this.$route.params.pathurl,
  //       polldleOptionResponses: [this.polldleOptionResponses]
  //     };

  //     // To vote for a PollDLE from REST web service
  //     axios({
  //       method: 'post',
  //       baseURL: "http://127.0.0.1:9991" + "/polldles/" + this.$route.params.pathurl + "/votes",
  //       data: JSON.stringify(polldleVote),
  //       headers: { 
  //         'Content-Type': 'application/json'
  //       }
  //     }).then(response => {
  //       if (response.status === 200) {
  //         console.log(this.$route.params.pathurl);
  //       } else if (response.status === 204) {
  //         this.state = stateResult.VOTE_ERROR;
  //         this.errorMessage = "Already voted !!!";
  //       }
  //     }).catch(() => {
  //       this.state = stateResult.VOTE_ERROR;
  //       this.errorMessage = "Problem to vote for this Polldle.";
  //     });
  //   },
  // }
}
    
</script>

<style>
</style>