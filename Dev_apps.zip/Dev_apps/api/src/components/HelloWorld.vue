<template>
  <q-page class="flex flex-center">
    <h1>Test router</h1>
  </q-page>
</template>

<style>
</style>

<script>
export default {
  name: 'HelloWorld'
}
</script>
