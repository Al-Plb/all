<template>
  <div class="background">
    <div class="q-pa-md text-center">
        <q-toggle v-model="value" dark />
    </div>
  </div>
</template>

<script>
export default {
  name:'Background',
  data: {
      value: true,
  }
  
}
</script>