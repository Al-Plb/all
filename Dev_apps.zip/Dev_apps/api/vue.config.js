module.exports = {
  pluginOptions: {
    quasar: {
      treeShake: true
    }
  },
  transpileDependencies: [
    /[\\\/]node_modules[\\\/]quasar[\\\/]/,
    /[\\\/]node_modules[\\\/]quasar[\\\/]/,
    /[\\\/]node_modules[\\\/]quasar[\\\/]/,
    /[\\\/]node_modules[\\\/]quasar[\\\/]/,
    /[\\\/]node_modules[\\\/]quasar[\\\/]/,
    /[\\\/]node_modules[\\\/]quasar[\\\/]/,
    /[\\\/]node_modules[\\\/]quasar[\\\/]/
  ]
}
